////
/**
  photoeditor

  NLURAIRefinePromptViewController.h
   
  Created by: terryc Don on 2024/7/2
  Copyright (c) 2024 Video Editor PTE. LTD.
*/

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol NLURAIRefinePromptViewControllerDelegate <NSObject>

- (void)onAIRefinePromptViewControllerDidSelect:(NSString*)prompt;

@end

@interface NLURAIRefinePromptViewController : UIViewController

@property(weak)id<NLURAIRefinePromptViewControllerDelegate> delegate;
@property(nonatomic)NSString* prompt;

@end

NS_ASSUME_NONNULL_END
