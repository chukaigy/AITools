////
/**
  photoeditor

  NLURMainAIToolMenuViewController.h
   
  Created by: terryc Don on 2024/3/19
  Copyright (c) 2024 click2mobile
*/

#import <UIKit/UIKit.h>
#import <CKAIToolsFramework/NLURAIToolConstants.h>

NS_ASSUME_NONNULL_BEGIN

@class NLURMainAIToolMenuViewController;

@protocol NLURMainAIToolMenuViewControllerDelete <NSObject>

- (void)onMainAIToolMenuClose:(NLURMainAIToolMenuViewController*)sender;
- (void)onMainAIToolMenuToolDidSelect:(NLURMainAIToolMenuViewController*)sender withToolType:(NLURAIToolType)type;

@end

@interface NLURMainAIToolMenuViewController : UIViewController

@property(weak, nonatomic)id<NLURMainAIToolMenuViewControllerDelete> deletegate;

- (void)reloadData;

@end

NS_ASSUME_NONNULL_END
