////
/**
  photoeditor

  NLURAIImageStyleGeneratiingViewController.h
   
  Created by: terryc Don on 2024/4/22
  Copyright (c) 2024 Video Editor PTE. LTD.
*/

#import <UIKit/UIKit.h>
#import <CKAIToolsFramework/NLURAIAppClient.h>
#import <CKAIToolsFramework/NLURAIToolConstants.h>

NS_ASSUME_NONNULL_BEGIN


@class NLURAIImageStyleGeneratingViewController;

@protocol NLURAIImageStyleGeneratingViewControllerDelegate <NSObject>

- (void)onAIImageStyleGeneratingViewApply:(NLURAIImageStyleGeneratingViewController*)sender resultImage:(UIImage*)resultImage isUseMode:(BOOL)isUseMode;

@end

@interface NLURAIImageStyleGeneratingViewController : UIViewController

@property(nonatomic)NSString* styleImgUrl;

@property(nonatomic)NSString* styleObjectId;

@property(nonatomic)UIImage* myRefImage;

@property(nonatomic, assign)BOOL useStyleImageAsRefImage;

@property(nonatomic)NSString* prompt;

@property(nonatomic, assign)NLURAIImageStyleMode currentStyleMode;

/** Yes use image as an import sticker to current project.
 No  edit image as an image to open a new project.
 */

@property(nonatomic, assign)BOOL isUseMode;

@property(weak) id<NLURAIImageStyleGeneratingViewControllerDelegate> delegate;
@property(nonatomic, assign)id <CKAIViewControllerBaseDeletage> uiDelegate;

@end

NS_ASSUME_NONNULL_END
