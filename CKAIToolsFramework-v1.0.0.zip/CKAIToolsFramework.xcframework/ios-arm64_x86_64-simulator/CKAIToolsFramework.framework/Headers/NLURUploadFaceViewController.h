////
/**
  photoeditor

 NLURUploadFaceViewController.h
   
  Created by: terryc Don on 2024/4/21
  Copyright (c) 2024 Video Editor PTE. LTD.
*/

#import <UIKit/UIKit.h>
#import <CKAIToolsFramework/NLURAICartoonmeGeneratingViewController.h>

NS_ASSUME_NONNULL_BEGIN

@class  NLURAIImageStyle;

@interface NLURUploadFaceViewController : UIViewController
@property(nonatomic)NLURAIImageStyle* style;

@property(weak) id<NLURAICartoonmeGeneratingViewControllerDelegate> delegate;

/** Yes use image as an import sticker to current project.
 No  edit image as an image to open a new project.
 */

@property(nonatomic, assign)BOOL isUseMode;
@end

NS_ASSUME_NONNULL_END
