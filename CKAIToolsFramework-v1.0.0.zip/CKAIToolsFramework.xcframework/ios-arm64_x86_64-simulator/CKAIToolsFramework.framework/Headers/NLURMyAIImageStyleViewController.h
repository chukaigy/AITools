////
/**
  photoeditor

  NLURMyAIImageStyleViewController.h
   
  Created by: terryc Don on 2024/4/24
  Copyright (c) 2024 Video Editor PTE. LTD.
*/

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol NLURMyAIImageStyleViewControllerDelete <NSObject>

- (void)onMyAIImageStyleViewDidSelectItemAt:(NSIndexPath*)indexPath styleFileName:(NSString*)styleFileName;

@end

@interface NLURMyAIImageStyleViewController : UIViewController
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property(nonatomic, nullable)NSIndexPath* currentSelectedIndexPath;
@property(weak) id<NLURMyAIImageStyleViewControllerDelete> delegate;
@end

NS_ASSUME_NONNULL_END
