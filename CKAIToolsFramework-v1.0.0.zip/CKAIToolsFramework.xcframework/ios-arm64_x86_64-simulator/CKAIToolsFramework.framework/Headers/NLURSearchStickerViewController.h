////
/**
  photoeditor

  NLURSearchStickerViewController.h
   
  Created by: terryc Don on 2024/3/18
  Copyright (c) 2024 click2mobile
*/

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN


@protocol NLURSearchStickerViewControllerDelegate <NSObject>

- (void)onSearchStickerViewcControllerComplete:(nullable NSArray*)items withError:(nullable NSError*)error;

@end

@interface NLURSearchStickerViewController : UIViewController

@property(weak, nonatomic)id<NLURSearchStickerViewControllerDelegate> searchStickerDelegate;

- (void)search:(NSString*)str;

@end

NS_ASSUME_NONNULL_END
