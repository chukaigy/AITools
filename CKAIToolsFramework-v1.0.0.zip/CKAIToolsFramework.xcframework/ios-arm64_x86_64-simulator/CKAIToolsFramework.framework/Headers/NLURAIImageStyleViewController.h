////
/**
  photoeditor

  NLURAIImageStyleViewController.h
   
  Created by: terryc Don on 2024/4/21
  Copyright (c) 2024 Video Editor PTE. LTD.
*/

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NLURAIImageStyleViewController : UIViewController

@property(nonatomic)BOOL isUseMode;

@end

NS_ASSUME_NONNULL_END
