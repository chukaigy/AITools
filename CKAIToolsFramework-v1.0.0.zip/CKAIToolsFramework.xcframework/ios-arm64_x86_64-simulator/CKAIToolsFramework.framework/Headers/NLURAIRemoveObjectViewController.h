////
/**
  photoeditor

  NLURAIRemoveObjectViewController.h
   
  Created by: terryc Don on 2024/3/31
  Copyright (c) 2024 click2mobile
*/

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class NLURAIRemoveObjectViewController;

@protocol NLURAIRemoveObjectViewControllerDelete <NSObject>

- (void)onAIRemoveObjectDone:(NLURAIRemoveObjectViewController*)sender resultImage:(UIImage*)resultImage;

@end
@interface NLURAIRemoveObjectViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@property (nonatomic)UIImage* previewImage;
@property (nonatomic)UIImage* image;
@property (nonatomic)UIImage* maskImage;

@property (nonatomic) NSString* prompt;


@property(weak)id<NLURAIRemoveObjectViewControllerDelete> delegate;

@end

NS_ASSUME_NONNULL_END
