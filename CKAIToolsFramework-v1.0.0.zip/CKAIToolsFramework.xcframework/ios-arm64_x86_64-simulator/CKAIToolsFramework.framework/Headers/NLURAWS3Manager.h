////
/**
  photoeditor

  NLURAWS3Manager.h
   
  Created by: terryc Don on 2024/3/20
  Copyright (c) 2024 click2mobile
*/

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NLURAWS3Manager : NSObject

+(NLURAWS3Manager*)shared;

- (void)uploadFile:(NSURL*)fileUrl completionHandler:(void(^)(NSString* fileId, NSString* fileUrl,  NSError* error))completion;

- (void)uploadFileWithData:(NSData*)data fileExtensionName:(NSString*)extensionName  completionHandler:(void(^)(NSString* fileId, NSString* fileUrl,  NSError* error))completion;

- (void)removeFile:(NSString*)fileId completionHandler:(nullable void(^)(NSString* fileId, NSError* error))completion;


// Must call it while app lauchs to clear some of undeleted files.
- (void)removeUnDeletedFileIds;

- (void)ignoreUnDeletedFileIds:(NSArray*)fileIds;

@end

NS_ASSUME_NONNULL_END
