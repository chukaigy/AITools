////
/**
  photoeditor

  NLURAIImageStylePromptViewController.h
   
  Created by: terryc Don on 2024/4/22
  Copyright (c) 2024 Video Editor PTE. LTD.
*/

#import <UIKit/UIKit.h>
#import <CKAIToolsFramework/NLURAIImageStyleGeneratingViewController.h>
#import <CKAIToolsFramework/NLURAIToolConstants.h>

NS_ASSUME_NONNULL_BEGIN

@class  NLURAIImageStyle;

@interface NLURAIImageStylePromptViewController : UIViewController<CKAIViewControllerBaseDeletage>

@property(nonatomic)NLURAIImageStyle* style;
@property(nonatomic)NSString* myStyleFilePath;

@property(nonatomic)UIImage* refImage;
@property(nonatomic, assign)BOOL useStyleImageAsRefImage;
@property(nonatomic, assign)NLURAIImageStyleMode currentStyleMode;

@property(nonatomic)BOOL isUseMode;

@property(weak) id<NLURAIImageStyleGeneratingViewControllerDelegate> delegate;
@property(weak) id<CKAIViewControllerBaseDeletage> uiDelegate;

@end

NS_ASSUME_NONNULL_END
