////
/**
  photoeditor

  NLURChooseRefImageViewController.h
   
  Created by: terryc Don on 2024/4/21
  Copyright (c) 2024 Video Editor PTE. LTD.
*/

#import <UIKit/UIKit.h>
#import <CKAIToolsFramework/NLURAIImageStyleGeneratingViewController.h>

NS_ASSUME_NONNULL_BEGIN

@class  NLURAIImageStyle;

@interface NLURChooseRefImageViewController : UIViewController
@property(nonatomic)NLURAIImageStyle* style;
@property(nonatomic)NSString* myStyleFilePath;
@property(nonatomic)BOOL isUseMode;

@property(weak) id<NLURAIImageStyleGeneratingViewControllerDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
