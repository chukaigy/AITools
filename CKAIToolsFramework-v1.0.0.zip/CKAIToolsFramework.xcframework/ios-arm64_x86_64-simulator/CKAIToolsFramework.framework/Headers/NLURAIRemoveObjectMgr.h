////
/**
  photoeditor

  NLURAIRemoveObjectMgr.h
   
  Created by: terryc Don on 2024/3/31
  Copyright (c) 2024 click2mobile
*/

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NLURAIRemoveObjectMgr : NSObject

+(NLURAIRemoveObjectMgr*)shared;

- (void)removeObject:(UIImage*)image maskImage:(UIImage*)maskImage completion:(void(^)(UIImage* image, NSError* error))completion;

@end

NS_ASSUME_NONNULL_END
