////
/**
  photoeditor

  NLURAIToolHelper.h
   
  Created by: terryc Don on 2024/3/22
  Copyright (c) 2024 click2mobile
*/

#import <Foundation/Foundation.h>
#import <CKAIToolsFramework/NLURAIToolConstants.h>

NS_ASSUME_NONNULL_BEGIN

@interface NLURAIToolHelper : NSObject

+(void)clearTempFiles;

+(NSString*)aiTempDirPath;

#pragma mark - Subscription Page

+ (NLURAIToolType)currentAnimatedAIToolIconType;

+(void)nextAnimatedAIToolIconType:(NLURAIToolType)curentType;

+ (NSString*)aiToolEventName:(NLURAIToolType)type;

#pragma mark - Remain Use Times

+ (int)totalUseTimes:(NLURAIToolType)type;

+ (int)remainUseTimes:(NLURAIToolType)type;

+ (void)decreaseRemainUseTimes:(NLURAIToolType)type;

#ifdef RESET_USE_REMAIN_TIEMES_FOR_AI_TOOL

+ (void)resetAIToolReusedTimesForAiService;

#endif 

@end

NS_ASSUME_NONNULL_END
