////
/**
  photoeditor

 NLURAICartoonmeGeneratingViewController.h
   
  Created by: terryc Don on 2024/4/22
  Copyright (c) 2024 Video Editor PTE. LTD.
*/

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN


@class NLURAICartoonmeGeneratingViewController;

@protocol NLURAICartoonmeGeneratingViewControllerDelegate <NSObject>

- (void)onAICartoonmeGeneratingViewApply:(NLURAICartoonmeGeneratingViewController*)sender resultImage:(UIImage*)resultImage isUseMode:(BOOL)isUseMode;

@end

@interface NLURAICartoonmeGeneratingViewController : UIViewController

@property(nonatomic)NSString* styleObjectId;

@property(nonatomic)NSString* styleImageUrl;

@property(nonatomic)UIImage* faceImage;


/** Yes use image as an import sticker to current project.
 No  edit image as an image to open a new project.
 */

@property(nonatomic, assign)BOOL isUseMode;

@property(weak) id<NLURAICartoonmeGeneratingViewControllerDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
