////
/**
  photoeditor

  NLURCustomizeAIArtStyleViewController.h
   
  Created by: terryc Don on 2024/4/10
  Copyright (c) 2024 click2mobile
*/

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class NLURUserCustomizeAIArtStyle;

@protocol NLURCustomizeAIArtStyleViewControllerDelete <NSObject>

- (void)onCustomizeAIArtStyleViewWillBeginDragging:(UIScrollView *)scrollView;

@end

@interface NLURCustomizeAIArtStyleViewController : UIViewController

@property(weak)id<NLURCustomizeAIArtStyleViewControllerDelete> delegate;

- (void)clearCurrentEditStyle;

- (NLURUserCustomizeAIArtStyle*)currentEditStyle;

- (void)fireAppliedStyle:(NLURUserCustomizeAIArtStyle*)style;

@end

NS_ASSUME_NONNULL_END
