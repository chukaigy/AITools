////
/**
  photoeditor

  NLURAISuperStyleStateManager.h
   
  Created by: terryc Don on 2024/7/24
  Copyright (c) 2024 Video Editor PTE. LTD.
*/

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN


@interface NLURAISuperStyleState: NSObject

@property(nonatomic)UIImage* faceImage;

@property(nonatomic)NSString* styleIconUrl;
@property(nonatomic)NSString* styleImageUrl;
@property(nonatomic)NSString* styleObjectId;

@property(nonatomic)NSString* senceIconUrl;
@property(nonatomic)NSString* senceImageUrl;

/** Yes use image as an import sticker to current project.
 No  edit image as an image to open a new project.
 */
@property(nonatomic, assign)BOOL isResultImageUsedAsSticker;

@end

@interface NLURAISuperStyleStateManager : NSObject

+(id)shared;

-(void)setLatestState:(NLURAISuperStyleState*)state;

- (NLURAISuperStyleState*)latestState;

- (NSInteger)maxFaceImageSize;

@end

NS_ASSUME_NONNULL_END
