////
/**
  photoeditor

  NLURAIStickerMakerViewController.h
   
  Created by: terryc Don on 2024/3/15
  Copyright (c) 2024 click2mobile
*/

#import <UIKit/UIKit.h>
#import <CKAIToolsFramework/NLURAIToolConstants.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString * const kNLUREditAiStickerUseModeNotice;
extern NSString * const kNLUREditAiStickerEditModeNotice;

@interface NLURAIStickerMakerViewController : UIViewController<CKAIViewControllerBaseDeletage>

/** Yes use sticker as an import sticker to current project.
 No  edit sticker as an image to open a new project.
 */
@property(nonatomic)BOOL isUseMode;
@property(weak)id <CKAIViewControllerBaseDeletage> uiDelegate;

@end

NS_ASSUME_NONNULL_END
