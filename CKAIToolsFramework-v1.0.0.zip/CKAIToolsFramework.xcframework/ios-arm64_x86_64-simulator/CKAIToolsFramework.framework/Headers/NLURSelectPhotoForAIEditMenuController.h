////
/**
  photoeditor

  NLURSelectPhotoForAIEditViewController.h
   
  Created by: terryc Don on 2024/3/22
  Copyright (c) 2024 click2mobile
*/

#import <UIKit/UIKit.h>
#import <CKAIToolsFramework/NLURMainAIToolMenuViewController.h>
#import <CKAIToolsFramework/NLURAIToolConstants.h>

NS_ASSUME_NONNULL_BEGIN

@interface NLUImage2PathPair : NSObject
@property(nonatomic)UIImage* image;
@property(nonatomic)id wdpath;
@end

@class NLURSelectPhotoForAIEditMenuController;

@protocol NLURSelectPhotoForAIEditMenuControllerDelete <NSObject>

- (void)onSelectPhotoForAiEditMenuDidSelect:(NLURSelectPhotoForAIEditMenuController*)sender index: (NSInteger)index wdPath:(id)path;

@end

@interface NLURSelectPhotoForAIEditMenuController : UIViewController

@property(nonatomic)NSArray* image2pathPairs;
@property(nonatomic)NLURAIToolType aiToolType;
@property(weak)id<NLURSelectPhotoForAIEditMenuControllerDelete> menuDelegate;

- (void)reloadData;

@end

NS_ASSUME_NONNULL_END
