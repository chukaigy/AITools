////
/**
  photoeditor

  NLURPrediction.h
   
  Created by: terryc Don on 2024/5/16
  Copyright (c) 2024 Video Editor PTE. LTD.
*/

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


@interface NLURPrediction : NSObject<NSCopying, NSCoding>

@property(nonatomic)NSString* message;
@property(nonatomic)NSString* predictionId;
@property(nonatomic)time_t updatedTime;

@property(nonatomic ,readonly)NSMutableArray* fileIds;

+(id)newObject:(NSString*)predictionId message:(NSString*)message;

- (void)addFileId:(NSString*)fileId;

- (BOOL)isExpired;

@end

NS_ASSUME_NONNULL_END
