////
/**
  photoeditor

  NLURAIRemoveObjectPromptViewController.h
   
  Created by: terryc Don on 2024/3/31
  Copyright (c) 2024 click2mobile
*/

#import <UIKit/UIKit.h>
#import <CKAIToolsFramework/NLURAIToolConstants.h>

NS_ASSUME_NONNULL_BEGIN
@class NLURAIRemoveObjectPromptViewController;

@protocol NLURAIRemoveObjectPromptViewControllerDelete <NSObject>

- (void)onAIRemoveObjectPromptViewDone:(NLURAIRemoveObjectPromptViewController*)sender resultImage:(UIImage*)resultImage;

@end

@interface NLURAIRemoveObjectPromptViewController : UIViewController <CKAIViewControllerBaseDeletage>
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@property (nonatomic)UIImage* previewImage;
@property (nonatomic)UIImage* image;
@property (nonatomic)UIImage* maskImage;

@property(weak)id<NLURAIRemoveObjectPromptViewControllerDelete> delegate;
@property(weak)id<CKAIViewControllerBaseDeletage>uiDelegate;

@end

NS_ASSUME_NONNULL_END
