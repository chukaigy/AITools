////
/**
  photoeditor

  NLURAIArtGeneratorViewController.h
   
  Created by: terryc Don on 2024/4/1
  Copyright (c) 2024 click2mobile
*/

#import <UIKit/UIKit.h>
#import <CKAIToolsFramework/NLURAIToolConstants.h>

NS_ASSUME_NONNULL_BEGIN



@interface NLURAIArtGeneratorViewController : UIViewController

/** Yes use image as an import sticker to current project.
 No  edit image as an image to open a new project.
 */
@property(nonatomic, assign)BOOL isUseMode;

@property(nonatomic, assign)id <CKAIViewControllerBaseDeletage> uiDelegate;

@end

NS_ASSUME_NONNULL_END
