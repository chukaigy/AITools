////
/**
  photoeditor

  NLURChooseRatioViewController.h
   
  Created by: terryc Don on 2024/7/1
  Copyright (c) 2024 Video Editor PTE. LTD.
*/

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN


typedef NS_ENUM(NSInteger, NLURRatioType) {
    kNLURRatioType_square = 0,
    kNLURRatioType_portrait_3_4, //w:h
    kNLURRatioType_portrait_9_16,
    kNLURRatioType_landscape_4_3,
    kNLURRatioType_landscape_16_9,
//    kNLURRatioType_customize,
    kNLURRatioType_count,
};

@protocol NLURChooseRatioViewControllerDelegate <NSObject>

- (void)onChooseRatioViewControllerSelectRatio:(NSUInteger)width height:(NSUInteger)height ratioName:(NSString*)ratioName ratioType:(NLURRatioType)ratioType;

@end

@interface NLURChooseRatioViewController : UIViewController

@property(weak)id<NLURChooseRatioViewControllerDelegate> delegate;

- (void)setRatio:(NLURRatioType)ratioType width:(NSUInteger)width height:(NSUInteger)height;

@end

NS_ASSUME_NONNULL_END
