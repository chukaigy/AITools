////
/**
  photoeditor

  NLURAppErrors.h
   
  Created by: terryc Don on 2024/3/18
  Copyright (c) 2024 click2mobile
*/

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


typedef NS_ENUM(NSInteger, NLURSearchAIStickerErrorCode) {
    kNLURSearchAIStickerErrorCode_Not_Inited = 200,
    kNLURSearchAIStickerErrorCode_InSearching,
    kNLURSearchAIStickerErrorCode_count
};

typedef NS_ENUM(NSInteger, NLURS3ErrorCode) {
    kNLURS3ErrorCode_Null_FileId = 100,
    kNLURS3ErrorCode_Null_FileUrl,
    kNLURS3ErrorCode_Wrong_FileUrl,
    kkNLURS3ErrorCode_Count
};

typedef NS_ENUM(NSInteger, NLURAICommErrorCode) {
    kNLURAICommErrorCode_FailedUploadImage = 1,
    kNLURAICommErrorCode_FailedUploadMaskImage, 
    kNLURAICommErrorCode_FailedDownloadResultImage,
    kNLURAICommErrorCode_ParameterIsNull,
    kNLURAICommErrorCode_HasNSFWContent,
    kNLURAICommErrorCode_Count
};

typedef NS_ENUM(NSInteger, NLURAIImageStyleErrorCode) {
    kNLURAIImageStyleErrorCode_FailedToSaveMyStyleImage = 300,
    kNLURAIImageStyleErrorCode_Count
};

extern NSString *const NLURAppErrorDomain;

extern NSString *const NLURAppErrorUserInfoMsgKey;

extern NSString *const NLURAAIAppClientErrorDomain;

NS_ASSUME_NONNULL_END
