////
/**
  photoeditor

  NLURAIArtGeneratingViewController.h
   
  Created by: terryc Don on 2024/4/2
  Copyright (c) 2024 click2mobile
*/

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class NLURAIArtGeneratingViewController;

@protocol NLURAIArtGeneratingViewControllerDelete <NSObject>

- (void)onAIArtGeneratingViewApply:(NLURAIArtGeneratingViewController*)sender resultImage:(UIImage*)resultImage isUseMode:(BOOL)isUseMode;

@end

@interface NLURAIArtGeneratingViewController : UIViewController

@property(nonatomic)NSString* styleName;
@property(nonatomic)NSString* styleValue;
@property(nonatomic)NSString* prompt;

/** Yes use image as an import sticker to current project.
 No  edit image as an image to open a new project.
 */

@property(nonatomic, assign)BOOL isUseMode;

@property(weak) id<NLURAIArtGeneratingViewControllerDelete> delegate;

@property(assign)NSUInteger outputImageWidth;
@property(assign)NSUInteger outputImageHeight;

@end

NS_ASSUME_NONNULL_END
