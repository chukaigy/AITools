////
/**
  photoeditor

  NLURDataAES25.h
   
  Created by: terryc Don on 2024/3/20
  Copyright (c) 2024 click2mobile
*/

#import <Foundation/Foundation.h>
#import <CKAIToolsFramework/NLURPrediction.h>

NS_ASSUME_NONNULL_BEGIN


typedef NS_ENUM(NSInteger, NLURAIImageStyleMode) {
    kNLURAIImageStyleMode_Strong = 0,
    kNLURAIImageStyleMode_Creative,
    kNLURAIImageStyleMode_Mix,
    kNLURAIImageStyleMode_Prompt,
    kNLURAIImageStyleMode_Count
};


@interface NLURAIAppClient : NSObject

+(NLURAIAppClient*)shared;

-(void)fetchToken:(nullable void(^)(NSString* token))complete;

- (void)updateTokenIfNeeded;

#pragma mark - AI Art Generator

- (void)aiAirGenerateImage:(NSString*)prompt styleName:(NSString*)styleName imageSize:(CGSize)imageSize complete:(void(^)(NSArray<NSURL *> * urls, NSError* error)) complete;

#pragma mark - Magic Edit

- (void)replaceObject:(NSString*)imageUrl maskUrl:(NSString*)maskUrl prompt:(NSString*)prompt outputImageSize:(CGSize)imageSize complete:(void(^)(NSArray * _Nullable resultImageUrls, NSError* _Nullable  error))complete;


- (void)removeObject:(NSString*)imageUrl maskImageUrl:(NSString*)maskImageUrl complete:(void(^)(NSURL* _Nullable resultImageUrl, NSError* _Nullable error))complete;

- (void)removeBg:(NSString*)imageUrl  complete:(void(^)(NSURL* _Nullable resultImageUrl, NSError* _Nullable error))complete; 

- (void)enchanceImage:(NSString*)imageUrl  complete:(void(^)(NSURL* _Nullable resultImageUrl, NSError* _Nullable error))complete; 

#pragma mark - AI Style

- (void)generateAIStyleImage:(NSString*)styleImgUrl styleObjectId:(NSString*)objectId refImg:(nullable NSString*)refImgUrl prompt:(nullable NSString*)prompt currentStyleMode:(NLURAIImageStyleMode)currentStyleMode complete:(void(^)(NSArray * _Nullable resultImageUrls, NLURPrediction* _Nullable prediction, NSError* _Nullable  error))complete;

/*
 Need use a timer to check the prediction result, 20 seconds is prefered.
 */
- (void)fetchPredictionResult:(NSString*)predictionId  complete:(void(^)(NSArray * _Nullable resultImageUrls, NSError* _Nullable  error))complete;

- (void)generateAICartoonmeImage:(NSString*)faceImgUrl styleImage:(NSString*)styleImgeUrl styleObjectId:(NSString*)objectId  complete:(void(^)(NSArray * _Nullable resultImageUrls, NLURPrediction* _Nullable prediction, NSError* _Nullable  error))complete;


- (void)retouchFaceImage:(NSString*)faceImgUrl  complete:(void(^)(NSURL * _Nullable resultImageUrl, NSError* _Nullable  error))complete;


#pragma mark - Refine Prompt

- (void)refinePrompt:(NSString*)prompt complete:(void(^)(NSArray * _Nullable prompts , NSError* _Nullable  error))complete;

#pragma mark - Cartoon me

- (void)makeSuperStyleImage:(NSString*)styleImgUrl styleObjectId:(NSString*)objectId identityImage:(nullable NSString*)faceImageUrl structImage:(nullable NSString*)structImageUrl prompt:(nullable NSString*)prompt complete:(void(^)(NSArray * _Nullable resultImageUrls,  NSError* _Nullable  error))complete;

- (void)testApi;

@end

NS_ASSUME_NONNULL_END
