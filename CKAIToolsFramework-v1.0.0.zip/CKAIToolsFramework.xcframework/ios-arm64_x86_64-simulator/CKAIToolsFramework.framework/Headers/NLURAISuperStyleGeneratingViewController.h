////
/**
  photoeditor

 NLURAISuperStyleGeneratingViewController.h
   
  Created by: terryc Don on 2024/7/24
  Copyright (c) 2024 Video Editor PTE. LTD.
*/

#import <UIKit/UIKit.h>
#import <CKAIToolsFramework/NLURAIAppClient.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString* const NLUR_AI_SUPERSTYLE_RESULTIMAGE_ACTION;

@interface NLURAISuperStyleGeneratingViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
