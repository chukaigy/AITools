////
/**
  photoeditor

  NLURAIToolConstants.h
   
  Created by: terryc Don on 2024/3/21
  Copyright (c) 2024 click2mobile
*/

#import <Foundation/Foundation.h>
#import <CKAIToolsFramework/NLURAIToolConstants.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString* const kNLURAITempDir;

typedef NS_ENUM(NSInteger, NLURAIToolType) {
    kNLURAIToolType_Unkown = -1,
    kNLURAIToolType_RemoveBg = 0,
    kNLURAIToolType_ArtGenerator,
    kNLURAIToolType_RemoveObject,
    kNLURAIToolType_AiStickerMaker,
    kNLURAIToolType_MagicBrush,
    kNLURAIToolType_ImageEnhance,
    kNLURAIToolType_ImageStyle,
    kNLURAIToolType_CartoonMe,
    kNLURAIToolType_Retouch,
    kNLURAIToolType_SuperStyle,
    kNLURAIToolType_Count,
};

@protocol CKAIViewControllerBaseDeletage <NSObject>

@required
- (UIWindow *)getMainWindow;

@optional
- (UIEdgeInsets)safeAreaInset;

@end


NS_ASSUME_NONNULL_END
